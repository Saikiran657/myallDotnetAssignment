﻿using Microsoft.EntityFrameworkCore;
using PhoneCoreMvcAssignment.Models;

namespace PhoneCoreMvcAssignment.DataAccessLayer
{
    public class PhoneContext : DbContext
    {
        public PhoneContext(DbContextOptions<PhoneContext> options) : base(options)
        {

        }
        public DbSet<Phone> Phone { get; set; }
    }
}

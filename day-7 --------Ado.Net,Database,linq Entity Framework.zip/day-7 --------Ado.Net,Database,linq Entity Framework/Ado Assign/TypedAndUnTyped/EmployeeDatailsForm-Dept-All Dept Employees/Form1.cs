﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmployeeDatailsForm_Dept_All_Dept_Employees
{
    public partial class Form1 : Form
    {
        private System.Data.SqlClient.SqlConnection objConn;
        private System.Data.SqlClient.SqlCommand objCmd;
        private System.Data.SqlClient.SqlDataAdapter da;
        DataSet ds;
        public Form1()
        {

            InitializeComponent();
            string strConn = @"Data Source=PRSQL;Initial Catalog=Venkat;Persist Security Info=True;User ID=labuser;Password=Welcome123$";
            objConn = new SqlConnection(strConn);
            string strCmdSelect = @"Select * from Employees";
            objCmd = new SqlCommand(strCmdSelect, objConn);

            da = new SqlDataAdapter();
            da.SelectCommand = objCmd;
            SqlCommandBuilder cmdBuilder = new SqlCommandBuilder(da);
            ds = new DataSet();


        }

        private void btnExit_Click(object sender, EventArgs e)
        {

        }

        private void btnShowDepartments_Click(object sender, EventArgs e)
        {
           
            da.Fill(ds, "Employees");
           // int did = Convert.ToInt32(ds.Tables["Employees"].Rows[0]["ID"]);
           // txtName.Text = (string)ds.Tables["MyEmployees"].Rows[0]["Name"];
            dgvDepartments.DataSource = ds;
           // dgvDepartments.DataMember = "MyEmployees";


            

            dgvEmployees.DataSource = ds;
           
        }

        private void dgvEmployees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvDepartments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dgv_dep_row_hedder_clicked(object sender, DataGridViewCellMouseEventArgs e)
        {

            DataGridViewRow row = dgvDepartments.SelectedRows[0];
            DataGridViewCellCollection cells = row.Cells;
            foreach (DataGridViewTextBoxCell cell in cells)
            {
                selectedDepID = int.Parse(cell.Value.ToString());
                break;
            }
            cmdEmployee.CommandText = "select e.EmpName as EmployeeName,e.EmpSalary as EmployeeSalary" + ",d.DeptName as DepartmentName from Employee e join Department d in e.DeptId on e.DeptId== d.DeptId";

            if (conn.State != ConnectionState.Closed)
            {

            }
            else
            {
                conn.Open();
                dgvEmployees = cmdEmployee.ExecuteReader();
                dtEmployees.Clear();
                dtEmployees.Load(drEmployee);
                dgvEmployees.DataSource = dtEmployees;
                conneState.Close();

            }

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace BasicsOfAdoDotNetDatabaseOperation
{
    class MainClass
    {
        static void Connected()
        {
            string strConn = @"Data Source=PRSQL;Initial Catalog=""saikiran DB"";User ID=labuser;Password=Welcome123$";
            SqlConnection objConn = new SqlConnection();
            objConn.ConnectionString = strConn;
            SqlCommand objCmd = new SqlCommand();
            string strCmd = @"Selectn * From Employees";
            objCmd.Connection = objConn;
            objCmd.CommandType = CommandType.Text;
            objCmd.CommandText = strCmd;

            SqlDataReader reader;
            objConn.Open();
            reader = objCmd.ExecuteReader();
            Console.Write("ID");
            Console.Write("\tName");
            Console.Write("\t Salary");
            Console.WriteLine("\t DeptID");
            Console.WriteLine("-------------------");
            while (reader.Read())
            {
                Console.Write(reader[0]);
                Console.Write("\t" + reader["Emp_Name"]);
                Console.Write(reader["Salary"]);
                Console.WriteLine("\t" + reader["Dept_ID"]);
            }
            reader.Close();
            objConn.Close();
        }
        static void Main()
        {
            Connected();
        }

    }
}

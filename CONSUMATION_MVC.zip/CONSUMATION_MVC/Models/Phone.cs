﻿namespace CONSUMATION_MVC.Models
{
    public class Phone
    {
        public int PhoneID { get; set; }
        public string PhoneName { get; set; }
        public int ModelID { get; set; }
        public string CompanyName { get; set; }
        public int CompanyID { get; set; }
    }
}

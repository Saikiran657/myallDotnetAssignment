﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CONSUMATION_MVC.Models;
using System.ComponentModel.Design;

namespace CONSUMATION_MVC.Controllers
{
    public class PhoneController : Controller
    {
        // GET: PhoneController
        public ActionResult Index()
        {
            HttpClient client;
            HttpResponseMessage response;
            List<Phone> Phone1 = new List<Phone>();

            
                client = new HttpClient();
                client.BaseAddress = new Uri("https://localhost:7034");
                response = client.GetAsync("api/Phone/GetPhone/").Result;
                var Phone = response.Content.ReadAsAsync<IEnumerable<Phone>>().Result;
                foreach (var p in Phone)
                {
                    Phone pho = new Phone();
                    pho.PhoneID = p.PhoneID;
                    pho.PhoneName = p.PhoneName;
                    pho.ModelID= p.ModelID;
                    pho.CompanyName = p.CompanyName;
                    pho.CompanyID = p.CompanyID;


                Phone1.Add(pho);

                }
                return View(Phone1);
                
        }

        // GET: PhoneController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PhoneController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PhoneController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PhoneController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PhoneController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PhoneController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PhoneController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}

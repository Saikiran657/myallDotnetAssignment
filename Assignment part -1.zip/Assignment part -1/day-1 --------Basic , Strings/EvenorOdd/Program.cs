﻿using System;
namespace Evenorodd
{
    class display
    {
        static void Main(string[] args)
        {
            int i;
            Console.Write("Enter a Number : ");
            i = int.Parse(Console.ReadLine());
            if (i % 2 == 0)
            {
                Console.Write("Its an Even Number");
                Console.Read();
            }
            else
            {
                Console.Write("Its an Odd Number");
                Console.Read();
            }
        }
    }
}

﻿using System;
public class Welcome
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter Username: ");
        string username = Console.ReadLine();
        Console.WriteLine("--------------------");
        Console.WriteLine("Hi!" + username);
        Console.Write("Welcome to the world of C#");
    }
}

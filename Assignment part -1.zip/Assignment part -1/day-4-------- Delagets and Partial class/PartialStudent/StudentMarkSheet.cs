﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialStudent
{
   public partial class Student
    {
        public string PrintMarkSheet()
        {
             return String.Format("Id :{0}\n Name :{1}\nClass:{2}\nMarks :{3}", this.Id, this.Name, this.Class, this.Marks);
        }

    }
}

﻿namespace SerializationStudent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.binSer = new System.Windows.Forms.Button();
            this.binDeSer = new System.Windows.Forms.Button();
            this.XmlSer = new System.Windows.Forms.Button();
            this.XmlDeSer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // binSer
            // 
            this.binSer.Location = new System.Drawing.Point(80, 71);
            this.binSer.Name = "binSer";
            this.binSer.Size = new System.Drawing.Size(110, 54);
            this.binSer.TabIndex = 0;
            this.binSer.Text = "Binary Serialiazation";
            this.binSer.UseVisualStyleBackColor = true;
            this.binSer.Click += new System.EventHandler(this.binSer_Click);
            // 
            // binDeSer
            // 
            this.binDeSer.Location = new System.Drawing.Point(80, 153);
            this.binDeSer.Name = "binDeSer";
            this.binDeSer.Size = new System.Drawing.Size(110, 75);
            this.binDeSer.TabIndex = 1;
            this.binDeSer.Text = "Binary DeSerialiazation";
            this.binDeSer.UseVisualStyleBackColor = true;
            this.binDeSer.Click += new System.EventHandler(this.binDeSer_Click);
            // 
            // XmlSer
            // 
            this.XmlSer.Location = new System.Drawing.Point(280, 71);
            this.XmlSer.Name = "XmlSer";
            this.XmlSer.Size = new System.Drawing.Size(89, 54);
            this.XmlSer.TabIndex = 2;
            this.XmlSer.Text = "XmlSerialization";
            this.XmlSer.UseVisualStyleBackColor = true;
            this.XmlSer.Click += new System.EventHandler(this.XmlSer_Click);
            // 
            // XmlDeSer
            // 
            this.XmlDeSer.Location = new System.Drawing.Point(280, 166);
            this.XmlDeSer.Name = "XmlDeSer";
            this.XmlDeSer.Size = new System.Drawing.Size(98, 48);
            this.XmlDeSer.TabIndex = 3;
            this.XmlDeSer.Text = "XmlSerialization";
            this.XmlDeSer.UseVisualStyleBackColor = true;
            this.XmlDeSer.Click += new System.EventHandler(this.XmlDeSer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 265);
            this.Controls.Add(this.XmlDeSer);
            this.Controls.Add(this.XmlSer);
            this.Controls.Add(this.binDeSer);
            this.Controls.Add(this.binSer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button binSer;
        private System.Windows.Forms.Button binDeSer;
        private System.Windows.Forms.Button XmlSer;
        private System.Windows.Forms.Button XmlDeSer;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace SerializationStudent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void binSer_Click(object sender, EventArgs e)
        {
            Student obj = new Student(1, "sai", 100, 14);
            BinaryFormatter binformatter = new BinaryFormatter();
            FileStream fs = new FileStream(@"C:\Users\labuser\source\repos\Student.txt", FileMode.OpenOrCreate, FileAccess.Write);
            binformatter.Serialize(fs, obj);
            fs.Close();
            MessageBox.Show("File Created");
        }

        private void XmlSer_Click(object sender, EventArgs e)
        {

        }

        private void binDeSer_Click(object sender, EventArgs e)
        {
            Student stud;
            try
            {
                BinaryFormatter binformatter = new BinaryFormatter();
                FileStream fs = new FileStream(@"C:\Users\labuser\source\repos\Student.txt", FileMode.Open, FileAccess.Read);
                stud = (Student)binformatter.Deserialize(fs);
                MessageBox.Show("Data is Deserialized\n studentDetails: Id :  " + stud.id + "name : " + stud.name + "marks: " + stud.marks + "age :" + stud.age);
                fs.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void XmlDeSer_Click(object sender, EventArgs e)
        {

        }
    }
}

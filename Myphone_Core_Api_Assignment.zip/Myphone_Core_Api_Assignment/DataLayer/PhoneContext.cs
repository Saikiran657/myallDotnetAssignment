﻿using Microsoft.EntityFrameworkCore;
using Myphone_Core_Api_Assignment.Models;
//using System.Data.Entity;

namespace Myphone_Core_Api_Assignment.DataLayer
{
    public class PhoneContext : DbContext
    {
        public PhoneContext(DbContextOptions<PhoneContext> options) : base(options)
        {

        }
        public DbSet<Phone> Phone { get; set; }
    }
}

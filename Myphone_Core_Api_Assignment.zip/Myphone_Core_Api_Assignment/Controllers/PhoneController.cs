﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Myphone_Core_Api_Assignment.repository;
using Myphone_Core_Api_Assignment.Models;

namespace Myphone_Core_Api_Assignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhoneController : ControllerBase
    {
        private readonly IPhoneRepository _Phone;
        //private readonly ILogger<> _logger;
        public PhoneController(IPhoneRepository Phone)
        {
            _Phone = Phone;
            //throw new ArgumentNullException(nameof(Comics));
        }

        [HttpGet]
        [Route("GetPhone")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Phone.GetPhone());
        }


        [HttpGet]
        [Route("GetPhoneByID/{Id}")]
        public async Task<IActionResult> GetPhoneByModelID(int ModelID)
        {
            return Ok(await _Phone.GetPhoneByModelID(ModelID));
        }

        [HttpGet]
        [Route("GetPhoneByComapanyName")]
        public async Task<IActionResult> GetPhoneByCompanyName(string CompanyName)
        {
            return Ok(await _Phone.GetPhoneByCompanyName(CompanyName));
        }


        [HttpPost]
        [Route("Addphone")]
        public async Task<IActionResult> Post(Phone phn)
        {
            var result = await _Phone.InsertPhone(phn);
            if (result.ModelID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }

        [HttpPut]
        [Route("Updatephone")]
        public async Task<IActionResult> Put(Phone Phn)
        {
            await _Phone.UpdatePhone(Phn);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeletePhone")]
        public JsonResult Delete(int PhoneID)
        {
           _Phone.DeletePhone(PhoneID);
            return new JsonResult("Deleted Successfully");
        }
    }
}

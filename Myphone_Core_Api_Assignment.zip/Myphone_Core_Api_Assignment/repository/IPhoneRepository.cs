﻿using Myphone_Core_Api_Assignment.Models;

namespace Myphone_Core_Api_Assignment.repository
{
    public interface IPhoneRepository
    {
        Task<IEnumerable<Phone>> GetPhone();
        Task<Phone> GetPhoneByModelID(int ModelID);
        Task<Phone> GetPhoneByCompanyName(string CompanyName);
        Task<Phone> InsertPhone(Phone objPhone);
        Task<Phone> UpdatePhone(Phone objPhone);
        bool DeletePhone(int PhoneID);
    }
}

﻿using Myphone_Core_Api_Assignment.Models;
using Myphone_Core_Api_Assignment.DataLayer;
using Microsoft.EntityFrameworkCore;

namespace Myphone_Core_Api_Assignment.repository
{
    public class PhoneRepository : IPhoneRepository
    {
        private readonly PhoneContext _Context;
        public PhoneRepository(PhoneContext context)
        {
            _Context = context ??
             throw new ArgumentNullException(nameof(context));
        }
        public bool DeletePhone(int PhoneID)
        {
            bool result = false;
            var Phone = _Context.Phone.Find(PhoneID);
            if (Phone != null)
            {
                _Context.Entry(Phone).State = EntityState.Deleted;
                _Context.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Phone>> GetPhone()
        {
            return await _Context.Phone.ToListAsync();
            throw new NotImplementedException();
        }

        public async Task<Phone> GetPhoneByModelID(int ModelID)
        {
            return await _Context.Phone.FindAsync(ModelID);
            throw new NotImplementedException();
        }

 

        public async Task<Phone> InsertPhone(Phone objPhone)
        {
            _Context.Phone.Add(objPhone).State = EntityState.Added;
            await _Context.SaveChangesAsync();
            return objPhone;
            throw new NotImplementedException();
        }

        public async Task<Phone> UpdatePhone(Phone objPhone)
        {
            _Context.Entry(objPhone).State = EntityState.Modified;
            await _Context.SaveChangesAsync();
            return objPhone;
            throw new NotImplementedException();
        }

        public async Task<Phone> GetPhoneByCompanyName(string CompanyName)
        {
            return await _Context.Phone.FindAsync(CompanyName);
            throw new NotImplementedException();
        }
    }
}

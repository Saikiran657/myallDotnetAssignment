﻿using WebApplication2.Models;

namespace SratchEmployeeWithApi.Models
{ 
    public interface IEmployeeRepository
    {
            IEnumerable<Employee> GetAll();
            Employee Get(int id);
            Employee AddProduct(Employee id);
            bool Update(Employee item);
            void Remove(int id);
    }
}

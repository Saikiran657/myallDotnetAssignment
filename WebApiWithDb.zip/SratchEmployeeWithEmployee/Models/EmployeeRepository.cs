﻿
using SratchEmployeeWithApi.Models;

namespace WebApplication2.Models
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private List<Employee> employees = new List<Employee>();
        private int _nextId = 1;
        public Employee AddEmployee(Employee id)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            id.Id = _nextId++;
            employees.Add(id);
            return id;
        }
        public Employee Get(int id)
        {
            return employees.Find(e => e.Id == id);
        }
        public IEnumerable<Employee> GetAll()
        {
            return employees;
        }
        public void Remove(int id)
        {
            employees.RemoveAll(p => p.Id == id);
        }
        public bool Update(Employee id)
        {
            if (id == null) { throw new ArgumentNullException("item"); }
            int index = employees.FindIndex(e => e.Id == id.Id);
            if (index == -1)
            {
                return false;
            }
            employees.RemoveAt(index);
            employees.Add(id);
            return true;
        }
    }
}
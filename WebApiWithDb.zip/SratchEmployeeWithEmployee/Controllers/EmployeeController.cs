﻿using Microsoft.AspNetCore.Mvc;

namespace SratchEmployeeWithApi.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
